@include('shared.html')

@include('shared.head', ['pageTitle' => 'Kraj'])

<body>
    @include('shared.navbar')

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Posiłek</h1>
        </div>
        <div class="card">
            <img src="{{ asset('storage/img/' . $meal->image) }}" class="rounded mx-auto d-block" />
        </div>
        @include('shared.session-error')
        <table class="table
                table-hover table-striped">
            <tbody>
                <tr>
                    <th scope="col">Dieta</th>
                    <td>{{ $meal->diet->name }}</td>
                </tr>
                <tr>
                    <th scope="col">Nazwa</th>
                    <td>{{ $meal->name }}</td>
                </tr>
                <tr>
                    <th scope="col">Opis</th>
                    <td>{{ $meal->description }}</td>
                </tr>
                <tr>
                    <th scope="col">Kalorie</th>
                    <td>{{ $meal->calories }}</td>
                </tr>
                <tr>
                    <th scope="col">Białko</th>
                    <td>{{ $meal->protein }}</td>
                </tr>
                <tr>
                    <th scope="col">Węglowodany</th>
                    <td>{{ $meal->carbohydrates }}</td>
                </tr>
                <tr>
                    <th scope="col">Tłuszcz</th>
                    <td>{{ $meal->fat }}</td>
                </tr>
                <tr>
                    @can('is-admin')
                        <th scope="col"></th>
                        <td><a href="{{ route('meals.edit', $meal->id) }}" class="btn btn-primary mb-2">Edycja</a>
                            <form method="POST" action="{{ route('meals.destroy', $meal->id) }}">
                                @csrf
                                @method('DELETE')
                                <input type="submit" class="btn btn-danger" value="Usuń" />
                            </form>
                        </td>
                    @endcan
                </tr>
            </tbody>
        </table>
    </div>

    @include('shared.footer')
</body>

</html>

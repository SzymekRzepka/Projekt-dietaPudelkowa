@include('shared.html')

@include('shared.head', ['pageTitle' => 'Posiłki'])

<body>
    @include('shared.navbar')

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Posiłki</h1>
        </div>
        @can('is-admin')
            <div class="row mb-2">
                <a href="{{ route('meals.create') }}">Dodaj nowy posiłek</a>
            </div>
        @endcan
        @include('shared.session-error')
        <div class="row">
            <div class="table-responsive-sm">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Dieta</th>
                            <th scope="col">Nazwa</th>
                            <th scope="col">Opis</th>
                            <th scope="col">Kalorie</th>
                            <th scope="col">Białko</th>
                            <th scope="col">Węglowodany</th>
                            <th scope="col">Tłuszcz</th>
                            @can('is-admin')
                                <th scope="col"></th>
                                <th scope="col"></th>
                            @endcan
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($meals as $meal)
                            <tr>
                                <th scope="row"><a
                                        href="{{ route('meals.show', $meal->id) }}">{{ $meal->id }}</a></th>
                                <td>{{ $meal->diet->name }}</td>
                                <td>{{ $meal->name }}</td>
                                <td>{{ $meal->description }}</td>
                                <td>{{ $meal->calories }}</td>
                                <td>{{ $meal->protein }}</td>
                                <td>{{ $meal->carbohydrates }}</td>
                                <td>{{ $meal->fat }}</td>
                                @can('is-admin')
                                    <td><a href="{{ route('meals.edit', $meal) }}">Edycja</a></td>
                                    <td>
                                        <form method="POST" action="{{ route('meals.destroy', $meal->id) }}">
                                            @csrf
                                            @method('DELETE')
                                            <input type="submit" class="btn btn-danger" value="Usuń"
                                                style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;" />
                                        </form>
                                    </td>
                                @endcan
                            </tr>
                        @empty
                            <tr>
                                <th scope="row" colspan="10">Brak posiłków.</th>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @include('shared.footer')
</body>

</html>

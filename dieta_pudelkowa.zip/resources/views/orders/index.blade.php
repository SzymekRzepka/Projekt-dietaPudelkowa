@include('shared.html')

@include('shared.head', ['pageTitle' => 'Zamówienia'])

<body>
    @include('shared.navbar')

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Zamówienia</h1>
        </div>
        @include('shared.session-error')
        <div class="row">
            <div class="table-responsive-sm">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Dieta</th>
                            <th scope="col">Imię</th>
                            <th scope="col">Email</th>
                            <th scope="col">Data zamówienia</th>
                            @can('is-admin')
                                <th scope="col"></th>
                            @endcan
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($orders as $order)
                            <tr>
                                <th scope="row">{{ $order->id }}</th>
                                <td>{{ $order->diet->name }}</td>
                                <td>{{ $order->user->name }}</td>
                                <td>{{ $order->user->email }}</td>
                                <td>{{ $order->order_date }}</td>
                                @can('is-admin')
                                    <td>
                                        <form method="POST" action="{{ route('orders.destroy', $order->id) }}">
                                            @csrf
                                            @method('DELETE')
                                            <input type="submit" class="btn btn-danger" value="Usuń"
                                                style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;" />
                                        </form>
                                    </td>
                                @endcan
                            </tr>
                        @empty
                            <tr>
                                <th scope="row" colspan="10">Brak zamówień.</th>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @include('shared.footer')
</body>

</html>

@include('shared.html')

@include('shared.head', ['pageTitle' => 'Katering ' . $diet->name])

<body>
    @include('shared.navbar')

    <div id="kateringi" class="container mt-5 mb-5">
        <div class="row m-2 text-center">
            <h1>Katering {{ $diet->name }}</h1>
        </div>
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="card">
                    <img src="{{ asset('storage/img/' . $diet->image) }}" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text">{{ $diet->description }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="posilki" class="container mt-5 mb-5">
        <div class="row m-2 text-center">
            <h1>Posiłki dla diety {{ $diet->name }}</h1>
        </div>
        <div class="row">
            @forelse ($diet->meals as $meal)
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="card">
                        <img src="{{ asset('storage/img/' . $meal->image) }}" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">{{ $meal->name }}</h5>
                            <p class="card-text">{{ $meal->description }}</p>
                        </div>
                    </div>
                </div>
            @empty
                <p>Brak posiłków przypisanych do tej diety.</p>
            @endforelse
        </div>
    </div>


    @include('shared.footer')

    </html>

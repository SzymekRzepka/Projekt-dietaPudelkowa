@include('shared.html')

@include('shared.head', ['pageTitle' => 'Katering dietetyczny'])

<body>
    @include('shared.navbar')

    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div id="start" class>
        <h1 class="text-center">Katering dietetyczny</h1>
    </div>

    <div id="katering" class="container mt-5">
        <div class="row">
            <h1>Diety</h1>
        </div>
        <div class="row">
            @forelse ($randomDiets as $diet)
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="card">
                        <img src="{{ asset('storage/img/' . $diet->image) }}" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">{{ $diet->name }}</h5>
                            <p class="card-text">{{ $diet->description }}</p>
                            <a href="{{ route('diets.show', ['id' => $diet->id]) }}" class="btn btn-primary">Więcej
                                szczegółów...</a>
                        </div>
                    </div>
                </div>
            @empty
                <p>Brak kateringu</p>
            @endforelse
        </div>
    </div>

    <div id="szczegoly" class="container mt-5 mb-5">
        <div class="row">
            <h1>Szczegóły</h1>
        </div>
        <div class="table-responsive-sm">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nazwa diety</th>
                        <th scope="col">Liczba posiłków</th>
                        <th scope="col">Liczba kalorii na dzień</th>
                        <th scope="col">Cena za dzień</th>
                        @can('is-admin')
                            <th scope="col"></th>
                        @endcan
                        @can('is-client')
                            <th scope="col"></th>
                        @endcan
                    </tr>
                </thead>
                <tbody>
                    @forelse ($diets as $diet)
                        <tr>
                            <th scope="row"><a href="{{ route('diets.show', $diet->id) }}">{{ $diet->id }}</a>
                            </th>
                            <td>{{ $diet->name }}</td>
                            <td>{{ $diet->number_of_meals }}</td>
                            <td>{{ $diet->calories_per_day }} kcal</td>
                            <td>{{ $diet->price_per_day }} PLN</td>
                            @can('is-admin')
                                <td><a href="{{ route('diets.edit', $diet->id) }}">Edycja</a></td>
                            @endcan
                            @can('is-client')
                                <td>
                                    <form action="{{ route('orders.store') }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="user_id" value="{{ auth()->user()->id }}">
                                        <input type="hidden" name="diet_type_id" value="{{ $diet->id }}">
                                        <input type="hidden" name="order_date" value="{{ now() }}">
                                        <button type="submit" class="btn btn-primary">Zamów dietę</button>
                                    </form>
                                </td>
                            @endcan
                        </tr>
                    @empty
                        <tr>
                            <th scope="row" colspan="6">Brak kateringu.</th>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>


    @include('shared.footer')

    </html>

@include('shared.html')

@include('shared.head', ['pageTitle' => 'Edytuj dane diety'])

<body>
    @include('shared.navbar')

    <div class="container mt-5 mb-5">

        @include('shared.session-error')

        <div class="row mt-4 mb-4 text-center">
            <h1>Edytuj dane diety</h1>
        </div>

        @include('shared.validation-error')

        <div class="row d-flex justify-content-center">
            <div class="col-6">
                <form method="POST" action="{{ route('diets.update', $diet->id) }}" class="needs-validation" novalidate
                    enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="form-group mb-2">
                        <label for="name" class="form-label">Nazwa</label>
                        <input id="name" name="name" type="text"
                            class="form-control @if ($errors->first('name')) is-invalid @endif"
                            value="{{ $diet->name }}">
                        <div class="invalid-feedback">Nieprawidłowa nazwa!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="description" class="form-label">Opis</label>
                        <textarea id="description" name="description" type="text" rows="5"
                            class="form-control @if ($errors->first('description')) is-invalid @endif">{{ $diet->description }}</textarea>
                        <div class="invalid-feedback">Nieprawidłowy opis!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="number_of_meals" class="form-label">Liczba posiłków</label>
                        <input id="number_of_meals" name="number_of_meals" type="number" min="1" step="1"
                            class="form-control @if ($errors->first('number_of_meals')) is-invalid @endif"
                            value="{{ $diet->number_of_meals }}">
                        <div class="invalid-feedback">Nieprawidłowa liczba posiłków!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="calories_per_day" class="form-label">Kalorie na dzień</label>
                        <div class="input-group mb-3">
                            <input id="calories_per_day" type="number" name="calories_per_day" min="0"
                                step="any" class="form-control @if ($errors->first('calories_per_day')) is-invalid @endif"
                                value="{{ $diet->calories_per_day }}">
                            <span class="input-group-text"> kcal</span>
                        </div>
                        <div class="invalid-feedback">Nieprawidłowa liczba kalorii!</div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="price_per_day" class="form-label">Cena</label>
                        <div class="input-group mb-3">
                            <input id="price_per_day" type="number" name="price_per_day" min="0" placeholder="0"
                                step="any" class="form-control @if ($errors->first('price_per_day')) is-invalid @endif"
                                value="{{ $diet->price_per_day }}">
                            <span class="input-group-text"> PLN</span>
                        </div>
                        <div class="invalid-feedback">Nieprawidłowa cena!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="image" class="form-label">Obrazek</label>
                        <input id="image" name="image" type="file"
                            class="form-control @if ($errors->first('image')) is-invalid @endif">
                        <div class="invalid-feedback">Nieprawidłowy obrazek!</div>
                    </div>
                    <div class="text-center mt-4 mb-4">
                        <input class="btn btn-success" type="submit" value="Wyślij">
                    </div>
                </form>
            </div>
        </div>
    </div>

    @include('shared.footer')
</body>

</html>

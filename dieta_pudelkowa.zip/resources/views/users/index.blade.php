@include('shared.html')

@include('shared.head', ['pageTitle' => 'Użytkownicy'])

<body>
    @include('shared.navbar')

    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div id="start" class>
        <h1 class="text-center">Uzytkownicy</h1>
    </div>


    <div id="szczegoly" class="container mt-5 mb-5">
        <div class="row">
            <h1>Uzytkownicy</h1>
        </div>
        <div class="table-responsive-sm">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">nazwa</th>
                        <th scope="col">email</th>

                    </tr>
                </thead>
                <tbody>
                    @forelse ($users as $user)
                        <tr>
                            <th scope="row"><a href="{{ route('users.show', $user->id) }}">{{ $user->id }}</a>
                            </th>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>

                        </tr>
                    @empty
                        <tr>
                            <th scope="row" colspan="6">Brak użytkowników.</th>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>


    @include('shared.footer')

    </html>

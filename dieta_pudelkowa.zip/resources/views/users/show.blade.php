@include('shared.html')

@include('shared.head', ['pageTitle' => 'Uzytkownik'])

<body>
    @include('shared.navbar')

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Użytkownik</h1>
        </div>
        @include('shared.session-error')
        <table class="table
                table-hover table-striped">
            <tbody>
                <tr>
                    <th scope="col">Uzytkownik</th>
                    <td>{{ $user->id }}</td>
                </tr>
                <tr>
                    <th scope="col">Nazwa</th>
                    <td>{{ $user->name }}</td>
                </tr>
                <tr>
                    <th scope="col">Email</th>
                    <td>{{ $user->email }}</td>
                </tr>
            </tbody>
        </table>
    </div>

    @include('shared.footer')
</body>

</html>

<footer class="container-fluid bg-body-tertiary fixed-bottom">
    <div class="row text-center pt-2">
        <p>&copy; Katering dietetyczny &ndash; 2024</p>
    </div>
</footer>

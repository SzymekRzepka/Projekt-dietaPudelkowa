<?php

namespace App\Http\Controllers;

use App\Models\DietType;
use App\Models\Meal;
use App\Http\Requests\StoreMealRequest;
use App\Http\Requests\UpdateMealRequest;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

class MealController extends Controller
{
    public function index()
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $meals = Meal::with('diet')->get();
        return view('meals.index', [
            'meals' => $meals
        ]);
    }

    public function create()
    {
        if (!Gate::allows('is-admin')) {
            abort(403);
        }
        return view('meals.create', [
            'diets' => DietType::all()
        ]);
    }

    public function store(StoreMealRequest $request)
    {
        $input = $request->except('image');

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/storage/img');
            $image->move($destinationPath, $imageName);

            $input['image'] = $imageName;
        }

        Meal::create($input);

        return redirect()->route('meals.index');
    }

    public function show($id)
    {
        $meal = Meal::with('diet')->findOrFail($id);
        return view('meals.show', [
            'meal' => $meal
        ]);
    }

    public function edit($id)
    {
        if (!Gate::allows('is-admin')) {
            abort(403);
        }
        $meal = Meal::findOrFail($id);
        return view('meals.edit', [
            'meal' => $meal,
            'diets' => DietType::all()
        ]);
    }

    public function update(UpdateMealRequest $request, Meal $meal)
    {
        if (!Gate::allows('is-admin')) {
            abort(403);
        }

        $input = $request->except('image');
        if ($request->hasFile('image')) {
            if ($meal->image) {
                Storage::delete('public/storage/img/' . $meal->image);
            }

            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/storage/img');
            $image->move($destinationPath, $imageName);

            $input['image'] = $imageName;
        } else {
            unset($input['image']);
        }
        $meal->update($input);
        return redirect()->route('meals.index');
    }

    public function destroy(Meal $meal)
    {
        if (!Gate::allows('is-admin')) {
            abort(403);
        }
        $meal->delete();
        return redirect()->route('meals.index');
    }
}

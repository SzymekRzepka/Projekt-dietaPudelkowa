<?php

namespace App\Http\Controllers;

use App\Models\DietType;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class OrderController extends Controller
{
    public function index()
    {
        if (!Gate::allows('is-admin')) {
            abort(403);
        }

        $orders = Order::with('user', 'diet')->get();
        return view('orders.index', [
            'orders' => $orders
        ]);
    }

    public function store(Request $request)
    {
        if (!Gate::allows('is-client')) {
            abort(403);
        }

        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'diet_type_id' => 'required|exists:diet_types,id',
            'order_date' => 'required|date',
        ]);

        try {
            $order = new Order();
            $order->user_id = $validated['user_id'];
            $order->diet_type_id = $validated['diet_type_id'];
            $order->order_date = $validated['order_date'];
            $order->save();

            return redirect()->back()->with('success', 'Zamówienie zostało złożone pomyślnie.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Wystąpił błąd podczas składania zamówienia.');
        }
    }

    public function destroy($id)
    {
        if (!Gate::allows('is-admin')) {
            abort(403);
        }
        $order = Order::findOrFail($id);
        $order->delete();

        return redirect()->route('orders.index');
    }
}

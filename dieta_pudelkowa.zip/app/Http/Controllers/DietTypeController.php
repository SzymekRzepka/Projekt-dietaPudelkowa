<?php

namespace App\Http\Controllers;

use App\Models\DietType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Gate;

class DietTypeController extends Controller
{
    public function index()
    {
        $diets = DietType::all();
        return view('diets.index', [
            'diets' => $diets,
            'randomDiets' => $diets->random(4),
        ]);
    }

    public function show($id)
    {
        $diet = DietType::with('meals')->findOrFail($id);
        return view('diets.show', compact('diet'));
    }

    public function edit($id)
    {
        $diet = DietType::findOrFail($id);
        return view('diets.edit', [
            'diet' => $diet,
        ]);
    }

    public function update(Request $request, $id)
    {
        Gate::authorize('is-admin');

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'number_of_meals' => 'required|integer',
            'calories_per_day' => 'required|integer',
            'price_per_day' => 'required|numeric',
            'image' => 'nullable|image',
        ]);

        $diet = DietType::findOrFail($id);
        $input = $request->except('image');

        if ($request->hasFile('image')) {
            if ($diet->image) {
                Storage::delete('public/storage/img/' . $diet->image);
            }

            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/storage/img');
            $image->move($destinationPath, $imageName);

            $input['image'] = $imageName;
        } else {
            unset($input['image']);
        }

        $diet->update($input);

        return redirect()->route('diets.index');
    }
}

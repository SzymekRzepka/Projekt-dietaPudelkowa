<?php

namespace App\Http\Controllers;

use App\Models\User;

class UserCOntroller extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('users.index', [
            'users' => $users,
        ]);
    }

    public function show($id)
    {
        $user = User::with('user')->findOrFail($id);
        return view('users.show', [
            'user' => $user
        ]);
    }
}

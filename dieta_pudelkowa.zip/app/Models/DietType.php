<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class DietType extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'description', 'number_of_meals', 'calories_per_day', 'price_per_day', 'image'
    ];

    public $timestamps = false;

    public function meals(): HasMany
    {
        return $this->hasMany(Meal::class, 'diet_type_id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'diet_type_id');
    }
}

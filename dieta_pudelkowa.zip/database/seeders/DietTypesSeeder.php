<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DietTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Schema::withoutForeignKeyConstraints(function () {
            DB::table('diet_types')->truncate();
        });

        DB::table('diet_types')->insert(
            [
                [
                    'name' => 'Keto',
                    'description' => 'Dieta ketogeniczna jest sposobem odżywiania się, który polega na ograniczeniu ilości węglowodanów do niezbędnego minimum.',
                    'number_of_meals' => 4,
                    'calories_per_day' => 2000,
                    'price_per_day' => 50.00,
                    'image' => 'keto.jpg',
                ],
                [
                    'name' => 'Wegetariańska',
                    'description' => 'Klasyczna dieta wegetariańska polega na eliminacji z jadłospisu wszelkiego rodzaju mięs – w tym drobiu, ryb i owoców morza.',
                    'number_of_meals' => 4,
                    'calories_per_day' => 1800,
                    'price_per_day' => 45.00,
                    'image' => 'vegetarian.jpg',
                ],
                [
                    'name' => 'Paleo',
                    'description' => 'Dieta paleo opiera się na wysokim spożyciu owoców, warzyw, ryb, jajek, nieprzetworzonego chudego mięsa i orzechów oraz małej ilości produktów mlecznych, zbóż i roślin strączkowych.',
                    'number_of_meals' => 3,
                    'calories_per_day' => 2200,
                    'price_per_day' => 55.00,
                    'image' => 'paleo.jpg',
                ],
                [
                    'name' => 'Wegańska',
                    'description' => 'Dieta wegańska polega na całkowitym wyeliminowaniu wszystkich produktów odzwierzęcych, w tym również nabiału, jaj, owoców morza i miodu.',
                    'number_of_meals' => 4,
                    'calories_per_day' => 2000,
                    'price_per_day' => 50.00,
                    'image' => 'vegan.jpg',
                ],
                [
                    'name' => 'Śródziemnomorska',
                    'description' => 'Opiera się o spożywanie produktów roślinnych, takich jak zboża, świeże warzywa i owoce, oliwa z oliwek, zioła, nasiona strączkowe, orzechy i pestki. Uzupełnieniem diety śródziemnomorskiej są pokarmy odzwierzęce, jak przetwory mleczne, ryby, owoce morza i chude mięso.',
                    'number_of_meals' => 4,
                    'calories_per_day' => 2100,
                    'price_per_day' => 52.00,
                    'image' => 'mediterranean.jpg',
                ],
                [
                    'name' => 'Nisko węglowodanowa',
                    'description' => 'Dieta niskowęglowodanowa polega na obniżeniu podaży węglowodanów na rzecz większego spożycia tłuszczy lub białka.',
                    'number_of_meals' => 3,
                    'calories_per_day' => 1800,
                    'price_per_day' => 48.00,
                    'image' => 'low_carb.jpg',
                ],
            ]
        );
    }
}

<?php

use App\Http\Controllers\MealController;
use App\Http\Controllers\DietTypeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('diets.index');
});



Route::controller(DietTypeController::class)->group(function () {
    Route::get('/diets', 'index')->name('diets.index');
    Route::get('/diets/{id}', 'show')->name('diets.show');
    Route::get('/diets/{id}/edit', 'edit')->name('diets.edit');
    Route::put('/diets/{id}', 'update')->name('diets.update');
});

Route::resource('meals', MealController::class);
Route::resource('orders', OrderController::class);

Route::controller(UserController::class)->group(function () {
    Route::get('/test', 'index')->name('user.index');
    Route::get('/test/{id}', 'show')->name('users.show');
});

Route::controller(AuthController::class)->group(function () {
    Route::get('/auth/login', 'login')->name('login');
    Route::post('/auth/login', 'authenticate')->name('login.authenticate');
    Route::get('/auth/logout', 'logout')->name('logout');
    Route::get('/auth/register', 'showRegistrationForm')->name('register');
    Route::post('/auth/register', 'register')->name('register.post');
});

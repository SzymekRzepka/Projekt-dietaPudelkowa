<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Katering dietetyczny</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php if(str_contains(request()->path(), 'diets')): ?> active <?php endif; ?>"
                        href="<?php echo e(route('diets.index')); ?>">Diety</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if(str_contains(request()->path(), 'meals')): ?> active <?php endif; ?>"
                        href="<?php echo e(route('meals.index')); ?>">Posiłki</a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if(str_contains(request()->path(), 'meals')): ?> active <?php endif; ?>"
                            href="<?php echo e(route('orders.index')); ?>">Zamówienia</a>
                    </li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav mb-2 mb-lg-0">
                <?php if(Auth::check()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"><?php echo e(Auth::user()->name); ?>, wyloguj się... </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Zaloguj się...</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Zarejestruj się...</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/shared/navbar.blade.php ENDPATH**/ ?>
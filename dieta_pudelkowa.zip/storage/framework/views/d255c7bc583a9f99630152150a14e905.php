<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-bs-theme="">
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/shared/html.blade.php ENDPATH**/ ?>
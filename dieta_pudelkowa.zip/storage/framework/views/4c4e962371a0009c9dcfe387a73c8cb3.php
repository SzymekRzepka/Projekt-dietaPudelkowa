<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Uzytkownik'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Użytkownik</h1>
        </div>
        <?php echo $__env->make('shared.session-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table
                table-hover table-striped">
            <tbody>
                <tr>
                    <th scope="col">Uzytkownik</th>
                    <td><?php echo e($user->id); ?></td>
                </tr>
                <tr>
                    <th scope="col">Nazwa</th>
                    <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                    <th scope="col">Email</th>
                    <td><?php echo e($user->email); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/users/show.blade.php ENDPATH**/ ?>
<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Katering ' . $diet->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="kateringi" class="container mt-5 mb-5">
        <div class="row m-2 text-center">
            <h1>Katering <?php echo e($diet->name); ?></h1>
        </div>
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="card">
                    <img src="<?php echo e(asset('storage/img/' . $diet->image)); ?>" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text"><?php echo e($diet->description); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="posilki" class="container mt-5 mb-5">
        <div class="row m-2 text-center">
            <h1>Posiłki dla diety <?php echo e($diet->name); ?></h1>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $diet->meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/img/' . $meal->image)); ?>" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($meal->name); ?></h5>
                            <p class="card-text"><?php echo e($meal->description); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Brak posiłków przypisanych do tej diety.</p>
            <?php endif; ?>
        </div>
    </div>


    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </html>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/diets/show.blade.php ENDPATH**/ ?>
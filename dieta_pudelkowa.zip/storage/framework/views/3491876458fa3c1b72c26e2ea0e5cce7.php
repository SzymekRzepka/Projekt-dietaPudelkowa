<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Posiłki'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Posiłki</h1>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
            <div class="row mb-2">
                <a href="<?php echo e(route('meals.create')); ?>">Dodaj nowy posiłek</a>
            </div>
        <?php endif; ?>
        <?php echo $__env->make('shared.session-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="table-responsive-sm">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Dieta</th>
                            <th scope="col">Nazwa</th>
                            <th scope="col">Opis</th>
                            <th scope="col">Kalorie</th>
                            <th scope="col">Białko</th>
                            <th scope="col">Węglowodany</th>
                            <th scope="col">Tłuszcz</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                                <th scope="col"></th>
                                <th scope="col"></th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><a
                                        href="<?php echo e(route('meals.show', $meal->id)); ?>"><?php echo e($meal->id); ?></a></th>
                                <td><?php echo e($meal->diet->name); ?></td>
                                <td><?php echo e($meal->name); ?></td>
                                <td><?php echo e($meal->description); ?></td>
                                <td><?php echo e($meal->calories); ?></td>
                                <td><?php echo e($meal->protein); ?></td>
                                <td><?php echo e($meal->carbohydrates); ?></td>
                                <td><?php echo e($meal->fat); ?></td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                                    <td><a href="<?php echo e(route('meals.edit', $meal)); ?>">Edycja</a></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('meals.destroy', $meal->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="submit" class="btn btn-danger" value="Usuń"
                                                style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;" />
                                        </form>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <th scope="row" colspan="10">Brak posiłków.</th>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/meals/index.blade.php ENDPATH**/ ?>
<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Katering dietetyczny'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div id="start" class>
        <h1 class="text-center">Katering dietetyczny</h1>
    </div>

    <div id="katering" class="container mt-5">
        <div class="row">
            <h1>Diety</h1>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $randomDiets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/img/' . $diet->image)); ?>" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($diet->name); ?></h5>
                            <p class="card-text"><?php echo e($diet->description); ?></p>
                            <a href="<?php echo e(route('diets.show', ['id' => $diet->id])); ?>" class="btn btn-primary">Więcej
                                szczegółów...</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Brak kateringu</p>
            <?php endif; ?>
        </div>
    </div>

    <div id="szczegoly" class="container mt-5 mb-5">
        <div class="row">
            <h1>Szczegóły</h1>
        </div>
        <div class="table-responsive-sm">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nazwa diety</th>
                        <th scope="col">Liczba posiłków</th>
                        <th scope="col">Liczba kalorii na dzień</th>
                        <th scope="col">Cena za dzień</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                            <th scope="col"></th>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-client')): ?>
                            <th scope="col"></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $diets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><a href="<?php echo e(route('diets.show', $diet->id)); ?>"><?php echo e($diet->id); ?></a>
                            </th>
                            <td><?php echo e($diet->name); ?></td>
                            <td><?php echo e($diet->number_of_meals); ?></td>
                            <td><?php echo e($diet->calories_per_day); ?> kcal</td>
                            <td><?php echo e($diet->price_per_day); ?> PLN</td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                                <td><a href="<?php echo e(route('diets.edit', $diet->id)); ?>">Edycja</a></td>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-client')): ?>
                                <td>
                                    <form action="<?php echo e(route('orders.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                        <input type="hidden" name="diet_type_id" value="<?php echo e($diet->id); ?>">
                                        <input type="hidden" name="order_date" value="<?php echo e(now()); ?>">
                                        <button type="submit" class="btn btn-primary">Zamów dietę</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th scope="row" colspan="6">Brak kateringu.</th>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>


    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </html>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/diets/index.blade.php ENDPATH**/ ?>
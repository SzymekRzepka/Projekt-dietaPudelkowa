<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Zarejestruj się'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5 mb-5">

        <?php echo $__env->make('shared.session-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row mt-4 mb-4 text-center">
            <h1>Zarejestruj się</h1>
        </div>

        <?php echo $__env->make('shared.validation-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row d-flex justify-content-center">
            <div class="col-10 col-sm-10 col-md-6 col-lg-4">
                <form method="POST" action="<?php echo e(route('register.post')); ?>" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-2">
                        <label for="name" class="form-label">Nazwa</label>
                        <input id="name" name="name" type="text"
                            class="form-control <?php if($errors->first('name')): ?> is-invalid <?php endif; ?>"
                            value="<?php echo e(old('name')); ?>">
                        <div class="invalid-feedback">Nieprawidłowa nazwa!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="email" class="form-label">Email</label>
                        <input id="email" name="email" type="text"
                            class="form-control <?php if($errors->first('email')): ?> is-invalid <?php endif; ?>"
                            value="<?php echo e(old('email')); ?>">
                        <div class="invalid-feedback">Nieprawidłowy email!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="password" class="form-label">Hasło</label>
                        <input id="password" name="password" type="password"
                            class="form-control <?php if($errors->first('password')): ?> is-invalid <?php endif; ?>">
                        <div class="invalid-feedback">Nieprawidłowe hasło!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="password-confirm" class="form-label">Potwierdź hasło</label>
                        <input id="password-confirm" name="password_confirmation" type="password"
                            class="form-control <?php if($errors->first('password_confirmation')): ?> is-invalid <?php endif; ?>">
                        <div class="invalid-feedback">Hasła muszą być takie same!</div>
                    </div>
                    <div class="text-center mt-4 mb-4">
                        <input class="btn btn-primary" type="submit" value="Zarejestruj się">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/auth/register.blade.php ENDPATH**/ ?>
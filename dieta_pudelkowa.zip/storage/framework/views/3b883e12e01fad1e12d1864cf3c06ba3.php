<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Kraj'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Posiłek</h1>
        </div>
        <div class="card">
            <img src="<?php echo e(asset('storage/img/' . $meal->image)); ?>" class="rounded mx-auto d-block" />
        </div>
        <?php echo $__env->make('shared.session-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table
                table-hover table-striped">
            <tbody>
                <tr>
                    <th scope="col">Dieta</th>
                    <td><?php echo e($meal->diet->name); ?></td>
                </tr>
                <tr>
                    <th scope="col">Nazwa</th>
                    <td><?php echo e($meal->name); ?></td>
                </tr>
                <tr>
                    <th scope="col">Opis</th>
                    <td><?php echo e($meal->description); ?></td>
                </tr>
                <tr>
                    <th scope="col">Kalorie</th>
                    <td><?php echo e($meal->calories); ?></td>
                </tr>
                <tr>
                    <th scope="col">Białko</th>
                    <td><?php echo e($meal->protein); ?></td>
                </tr>
                <tr>
                    <th scope="col">Węglowodany</th>
                    <td><?php echo e($meal->carbohydrates); ?></td>
                </tr>
                <tr>
                    <th scope="col">Tłuszcz</th>
                    <td><?php echo e($meal->fat); ?></td>
                </tr>
                <tr>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                        <th scope="col"></th>
                        <td><a href="<?php echo e(route('meals.edit', $meal->id)); ?>" class="btn btn-primary mb-2">Edycja</a>
                            <form method="POST" action="<?php echo e(route('meals.destroy', $meal->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" class="btn btn-danger" value="Usuń" />
                            </form>
                        </td>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/meals/show.blade.php ENDPATH**/ ?>
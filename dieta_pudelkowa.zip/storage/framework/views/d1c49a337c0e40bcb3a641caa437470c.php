<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Edytuj dane posiłku'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5 mb-5">

        <?php echo $__env->make('shared.session-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row mt-4 mb-4 text-center">
            <h1>Edytuj dane posiłku</h1>
        </div>

        <?php echo $__env->make('shared.validation-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row d-flex justify-content-center">
            <div class="col-6">
                <form method="POST" action="<?php echo e(route('meals.update', $meal->id)); ?>" class="needs-validation" novalidate
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group mb-2">
                        <label for="diet_type_id" class="form-label">Typ diety</label>
                        <select id="diet_type_id" name="diet_type_id"
                            class="form-select <?php if($errors->first('diet_type_id')): ?> is-invalid <?php endif; ?>">
                            <?php $__currentLoopData = $diets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($diet->id); ?>" <?php if($diet->name == $meal->diet->name): ?> selected <?php endif; ?>>
                                    <?php echo e($diet->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">Nieprawidłowy typ diety!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="name" class="form-label">Nazwa</label>
                        <input type="text" id="name" name="name"
                            class="form-control <?php if($errors->first('name')): ?> is-invalid <?php endif; ?>"
                            value="<?php echo e($meal->name); ?>" required>
                        <div class="invalid-feedback">Nieprawidłowa nazwa!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="description" class="form-label">Opis</label>
                        <textarea id="description" name="description" class="form-control <?php if($errors->first('description')): ?> is-invalid <?php endif; ?>"
                            required><?php echo e($meal->description); ?></textarea>
                        <div class="invalid-feedback">Nieprawidłowy opis!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="calories" class="form-label">Kalorie</label>
                        <input type="number" id="calories" name="calories"
                            class="form-control <?php if($errors->first('calories')): ?> is-invalid <?php endif; ?>"
                            value="<?php echo e($meal->calories); ?>" required>
                        <div class="invalid-feedback">Nieprawidłowa liczba kalorii!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="protein" class="form-label">Białko</label>
                        <input type="number" id="protein" name="protein"
                            class="form-control <?php if($errors->first('protein')): ?> is-invalid <?php endif; ?>"
                            value="<?php echo e($meal->protein); ?>" required>
                        <div class="invalid-feedback">Nieprawidłowa liczba białka!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="carbohydrates" class="form-label">Węglowodany</label>
                        <input type="number" id="carbohydrates" name="carbohydrates"
                            class="form-control <?php if($errors->first('carbohydrates')): ?> is-invalid <?php endif; ?>"
                            value="<?php echo e($meal->carbohydrates); ?>" required>
                        <div class="invalid-feedback">Nieprawidłowa liczba węglowodanów!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="fat" class="form-label">Tłuszcz</label>
                        <input type="number" id="fat" name="fat"
                            class="form-control <?php if($errors->first('fat')): ?> is-invalid <?php endif; ?>"
                            value="<?php echo e($meal->fat); ?>" required>
                        <div class="invalid-feedback">Nieprawidłowa liczba tłuszczu!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="image" class="form-label">Nazwa obrazka</label>
                        <input id="image" name="image" type="file"
                            class="form-control <?php if($errors->first('image')): ?> is-invalid <?php endif; ?>">
                        <div class="invalid-feedback">Nieprawidłowa nazwa obrazka!</div>
                    </div>
                    <div class="text-center mt-4 mb-4">
                        <input class="btn btn-success" type="submit" value="Wyślij">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\LENOVO\Desktop\projekt_AI\resources\views/meals/edit.blade.php ENDPATH**/ ?>